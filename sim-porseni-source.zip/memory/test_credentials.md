# Test Credentials — SIM Porseni MI Plosoklaten

## Super Admin (seeded)
- email: super@porseni.id
- password: admin123
- role: super_admin

Note: DB (porseni_db) is re-seeded with only the super_admin account on continuation.
Other users (admin_madrasah, panitia) are created by super_admin via Manajemen Pengguna
(default password when created directly: 12345678).
